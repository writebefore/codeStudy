module.exports = {
  plugin: {
    'postcss-pxtorem': {
      rootvalue: 37.5,
      propList: ['*']
    }
  }
}