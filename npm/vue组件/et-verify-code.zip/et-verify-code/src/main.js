import EtVerifyCode from './et-verify-code.vue'
EtVerifyCode.install = Vue => Vue.component(EtVerifyCode.name, EtVerifyCode)
export default EtVerifyCode