module.exports = {
  css: {
    extract: false // 组件的样式是否另外打包成单独的css文件
  },
  productionSourceMap: false
}